// Verified against: Bat.java (26.1.2)
package net.vanillaoutsider.betterbats.ai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.phys.Vec3;
import net.vanillaoutsider.betterbats.BatStateAccessor;

import java.util.EnumSet;

/**
 * AI Goal for Bats to scatter in panic away from sound/vibration sources.
 */
public class BatPanicGoal extends Goal {
    private final Bat bat;
    private final BatStateAccessor accessor;

    public BatPanicGoal(Bat bat) {
        this.bat = bat;
        this.accessor = (BatStateAccessor) bat;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        return this.accessor.betterbats$isPanicked();
    }

    @Override
    public void start() {
        // Disperse from group when panicked
        if (this.bat instanceof net.dasik.social.api.group.GroupMember gm) {
            gm.setLeader(null);
        }
        // Play panic sounds (mixed takeoff and low-pitch flap)
        this.bat.playSound(net.minecraft.sounds.SoundEvents.BAT_TAKEOFF, 0.8f, 1.0f);
        this.bat.playSound(net.minecraft.sounds.SoundEvents.PHANTOM_FLAP, 0.5f, 0.6f);
    }

    @Override
    public boolean canContinueToUse() {
        return this.accessor.betterbats$isPanicked();
    }

    @Override
    public void tick() {
        Vec3 panicSource = this.accessor.betterbats$getPanicSource();
        Vec3 dir;
        if (panicSource != null) {
            // Fly away from the source
            dir = this.bat.position().subtract(panicSource);
        } else {
            // Fly in a random direction
            dir = new Vec3(this.bat.getRandom().nextDouble() - 0.5, this.bat.getRandom().nextDouble() - 0.5, this.bat.getRandom().nextDouble() - 0.5);
        }
        
        if (dir.lengthSqr() < 0.01) {
            dir = new Vec3(this.bat.getRandom().nextDouble() - 0.5, 0.5, this.bat.getRandom().nextDouble() - 0.5);
        }
        
        // Rapid flight speed
        this.bat.setDeltaMovement(this.bat.getDeltaMovement().add(dir.normalize().scale(0.15)).scale(0.85));
        
        // Tick down panic time
        int ticks = this.accessor.betterbats$getPanicTicks();
        if (ticks > 0) {
            this.accessor.betterbats$setPanicTicks(ticks - 1);
        }
    }
}
