// Verified against: Minecraft.java (26.1 Snapshot 11+)
package net.vanillaoutsider.betterbats;

import net.fabricmc.api.ClientModInitializer;

public class BetterBatsFabricClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Client initialization
    }
}
